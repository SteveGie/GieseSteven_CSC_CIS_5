/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steven Giese
 * Russian Roulette
 * Created on January 25, 2022, 12:30 AM
 * Ver: 0.T.M, test to make a menu and stuff
 * Testing saving and loading data.
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Seed
unsigned seed=time(0);
float rper=2147483647.0f;

/*+----------------+
 *│ Prototype Zone │
 *+----------------+*/
void p1game();
void p4game();
void viewsts();


int main(int argc, char** argv) {
    char sel;
    cout<<"Welcome to menu test\n"<<"1 Player Game"<<setw(8)<<"s\n"<<"4 Player Game"<<setw(8)<<"m\n"<<"View Scores"<<setw(10)<<"v\n"<<"Quit"<<setw(17)<<"q\n";
    while(sel !='q' && sel!='Q'){
        cin>>sel;
        if(sel=='s' || sel=='S') p1game();
        else if(sel=='m' || sel=='M') p4game();
        else if(sel=='v' || sel=='V') viewsts();
        else cout<<"Invalid input, only s, m, v, or q\n";
    }
    return 0;
}
void p1game(){
    int fun=0;
    while(fun !=4){
    cout<<"You selected 1 Player Game\n"<<"select random numbers, except 4\n";
    cin>>fun;
    }
}
void p4game(){
    int fun=0;
    while(fun !=4){
    cout<<"You selected 4 Player Game\n"<<"select random numbers, except 4\n";
    cin>>fun;
    }
}
void viewsts(){
    cout<<"Yo, stats aint avalible right now\n";
}


/* <><><To Do list><><>
 * Make a 1 player mode with 3 com competitors. []
 * Make a 4 player mode, with insertable names []
 * Make com smart []
 * Save times died and won []
 */

/*~~~~~Notes~~~~~~~~~~~~[-][X]
 * Max Rand is 2147483647.0f │
 * or thing: ||
 */