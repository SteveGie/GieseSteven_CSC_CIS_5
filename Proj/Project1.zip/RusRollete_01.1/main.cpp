/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steven Giese
 * Russian Roulette
 * Created on January 25, 2022, 12:30 AM
 * Ver: 0.0.1, Official attempt to make the game 
 * Testing saving and loading data.
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;
//Seed
const float RPER=2147483647.0f;

 //Number of bullet slots
int main(int argc, char** argv) {
    const float CHAMB=6;
    srand(static_cast<unsigned int>(time(0)));
    char sel='l';
    int pick=0, wins=0, loss=0;
    cout<<"Welcome to Russian Roulette\n"<<"1 Player Game"<<setw(8)<<"s\n";
    cout<<"View Scores"<<setw(10)<<"v\n"<<"Info"<<setw(17)<<"i\n"<<"Quit"<<setw(17)<<"q\n";
    while(sel !='q' && sel!='Q'){
        cin>>sel;
        switch(sel){//Making switch case
            case 's': pick=1; break;
            case 'S': pick=1; break;
            case 'i': pick=2; break;
            case 'I': pick=2; break;
            case 'v': pick=3; break;
            case 'V': pick=3; break;
            case 'q': break;
            case 'Q': break;
            default : cout<<"Invalid input, only s, m, v, or q\n";
        }
        if(pick==1){
            pick=0;
    string com="Mike"; //Make this random
    bool pdie=true, cdie=true, win=false;//__die = on death, equals false, nspun = cylinder not spun
    fstream score, newfi;
    char sel, cont;
    float chance;
    int bull;
    bull=(rand()%(5-1+1))+1;
    cout<<"You four are trapped in a room with a gun."
        <<"Its your turn\n";
    while(pdie){
        cout<<"Shoot Self: s, or Spin Cylinder r\n";
        cin>>sel;
        while(sel!='s'&&sel!='S'&&sel!='r'&&sel!='R'){ //No selection
            cout<<"Cmon, quit delaying. s, or r?\n";
            cin>>sel;
        }
        if(sel=='r'||sel=='R'){ //Spinning the cylinder 
            bull=(rand()%(5-1+1))+1;
            cout<<"You spun the chamber, your fate is unclear.\n";
            sel='s';
        }
        if(sel=='s'||sel=='S'){ //Shoot self
            if(bull==CHAMB){
                cout<<"BAM! you died\nYou are back at the main menu, select s, m, v, i, or q\n";
                bull=0;
                pdie=false;
                
            score.open("score.dat");
            if(score){ //Saving to a file
                score>>wins;
                score>>loss;
                score.close();
                score.open("score.dat");
                if(wins) wins++;
                else loss++;
                score<<wins<<endl;
                score<<loss<<endl;
                score.close();
            }
            else{ //Making a new file and saving
                score.close();
                newfi.open("score.dat");
                newfi.close();
                score.open("score.dat");
                score>>wins;
                score>>loss;
                score.seekg(0, std::ios::beg);
                if(wins) wins++;
                else loss++;
                score<<wins<<endl;
                score<<loss<<endl;
                score.close();
            }
            }
            else{
                cout<<"*Click*, whew, lucky this time.\n";
                ++bull; 
            }
        }
        //com
        if(pdie){
          cout<<"You pass the gun to "<<com<<endl;
          cout<<"(Enter Any Key to COntinue)\n";
          cin>>cont;
          float spin=rand()/RPER; //Deciding the chance to spin
          if(rand()>spin){
              bull=(rand()%(6-1+1))+1;
              cout<<"They spun the cylinder\n";
          }
          if(bull==CHAMB){
              cout<<"They pointed the gun to their head\n";
            cout<<"BAM! "<<com<<" died... you won!\nYou are back at the main menu, select s, m, v, i, or q\n";
            bull=0;
            pdie=false;
            win=true;
            score.open("score.dat");
            if(score){ //Saving to file
                score>>wins;
                score>>loss;
                score.seekg(0, std::ios::beg);
                if(wins) wins++;
                else loss++;
                score<<wins<<endl;
                score<<loss<<endl;
                score.close();
            }
            else{ //Makes a new file and saves
                score.close();
                newfi.open("score.dat");
                newfi.close();
                score.open("score.dat");
                score>>wins;
                score>>loss;
                score.seekg(0, std::ios::beg);
                if(wins) wins++;
                else loss++;
                score<<wins<<endl;
                score<<loss<<endl;
                score.close();
            }
            }
            else{
                cout<<"*Click*\n";
                ++bull;
            }
        }
        cout<<"It's back to you\n";    
    }
        }
        if(pick==2){
            pick=0;
        cout<<"You know Russian Roulette, The high risk no reward game\n"
        <<"But basically, there is a one in six chance that you'll shoot yourself\n"
        <<"This chance increases after each shot of course, as less blanks are left in the chamber\n"
        <<"You can spin the cylinder to potentially increase you chance of survival\n";
        }
        if(pick==3){
            pick=0;
            fstream score;
            score.open("score.dat");
            if(score){
                score>>wins;
                score>>loss;
                cout<<"You have won "<<wins<<" times, and lost "<<loss<<endl;
                score.close();
            }
            else{
                cout<<"You have not played a game yet\n";
            }
            
        }
    
}
    return 0;
}

/*~~~~~Notes~~~~~~~~~~~~[-][X]
 * Max Rand is 2147483647.0f │
 * or thing: ||
 */