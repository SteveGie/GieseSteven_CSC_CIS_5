/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steve
 *
 * Created on February 2, 2022, 10:53 PM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
/*
 * 
 */
void names(string[], int);
void nmakefil();
int main(int argc, char** argv) {
    int size=10, count=0;
    string name1, name2, name3, temp;
    fstream logdude;
    logdude.open("names.txt");
    if(!logdude){
        cout<<"Creating a file\n";
        nmakefil();
        logdude.open("names.txt");
    }
    cout<<"Pushed position to end\n";
    cout<<"Insert random names!\n";
    logdude.seekg (0, ios::end);
    cin>>name1;
    logdude<<name1;
    cin>>name2;
    logdude<<name2;
    cin>>name3;
    logdude<<name3;
    logdude.close();
    return 0;
}
void names(string name[], int size){

}
void nmakefil(){
    ofstream logdude;
    logdude.open("names.txt");
    cout<<"Should have created a file\n";
    logdude.close();
}