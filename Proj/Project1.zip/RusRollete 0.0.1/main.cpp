/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steven Giese
 * Russian Roulette
 * Created on January 25, 2022, 12:30 AM
 * Ver: 0.0.1, Official attempt to make the game 
 * Testing saving and loading data.
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Seed
unsigned seed=time(0);
const float RPER=2147483647.0f;

/*+----------------+
 *│ Prototype Zone │
 *+----------------+*/
void p1game();  //Single Player game
void p4game();  //4 player game
void viewsts(); //Load save data, times died and times won.
void instruc(); //Instructions

const float CHAMB=6; //Number of bullet slots
int main(int argc, char** argv) {
    srand(seed);
    char sel;
    cout<<"Welcome to Russian Roulette\n"<<"1 Player Game"<<setw(8)<<"s\n"<<"4 Player Game"<<setw(8)<<"m\n";
    cout<<"View Scores"<<setw(10)<<"v\n"<<"Info"<<setw(17)<<"i\n"<<"Quit"<<setw(17)<<"q\n";
    while(sel !='q' && sel!='Q'){
        cin>>sel;
        if(sel=='s' || sel=='S') p1game();
        else if(sel=='m' || sel=='M') p4game();
        else if(sel=='v' || sel=='V') viewsts();
        else if(sel=='i' || sel=='I') instruc();
        else if(sel=='q' || sel=='Q') break;
        else cout<<"Invalid input, only s, m, v, or q\n";
    }
    return 0;
}
void p1game(){ //for now, no opponents.
    string com1="Bob. 2", com2="Mike. 3", com3="Karen. 4"; //Make this random
    bool pdie=true, c1die, c2die, c3die, nspun=true;//__die = on death, equals false, nspun = cylinder not spun
    char sel;
    float chance;
    int bull=1;
    cout<<"You four are trapped in a room with a gun. Guess you know what this means...\nRUSSIAN ROULETTE!! YAAAY\n"
        <<"The gun starts on your side, damn, just your luck, whats your move?\n";
    while(pdie){
        cout<<"Shoot Self: s, Shoot Opponent(Univalible): a, or Spin Cylinder r\n";
        cin>>sel;
        while(sel!='s'&&sel!='S'&&sel!='r'&&sel!='R'){ //No selection
            cout<<"Cmon, quit delaying. s, a, or r?\n";
            cin>>sel;
        }
        if(sel=='r'||sel=='R'){ //Spinning the cylinder 
            if(nspun){
                bull=(rand()%(6-1+1))+1;
                cout<<"You spun the chamber, your fate is unclear.\n"<<bull<<" Debug Stuff\n";
                nspun=false;
            }
            else{cout<<"You already spun the cylinder\n";}
            continue;
        }
        chance=bull/CHAMB;  //Shootin yo self,
        if(rand()/RPER<chance){
            cout<<"BAM! you died\n"<<bull<<" "<<chance<<" Debug Stuff\nYou are back at the main menu, select s, m, v, i, or q\n";
            bull=1;
            pdie=false;
        }
        else{
            cout<<"*Click*, whew, lucky this time.\n"<<bull<<" "<<chance<<" Debug Stuff\n";
            ++bull;
            nspun=true;
        }
    }
    
}
void p4game(){
    int fun=0;
    while(fun !=4){
    cout<<"You selected 4 Player Game\n"
        <<"This currently doesn't work, so just type numbers\n"
        <<"Just not four, I mean, unless you wanna leave or somethin\n";
    cin>>fun;
    }
}
void viewsts(){
    cout<<"Yo, stats aint avalible right now\n";
}
void instruc(){
    cout<<"You know Russian Roulette, The high risk no reward game\n"
        <<"But basically, there is a one in six chance that you'll shoot yourself\n"
        <<"This chance increases after each shot of course, as less blanks are left in the chamber\n"
        <<"However, you can also shoot an opponent if your feeling unlucky\n"
        <<"But, if you fire a blank, you have to point the gun at yourself and shoot\n"
        <<"Lastly, you can spin the cylinder, if too many blanks have gone by.\n"
        <<"You can only spin the cylinder once per turn.\n"
        <<"Spinning also means you will not be able to shoot an opponent that turn\n";
}

/* <><><To Do list><><>
 * Make a 1 player mode with 3 com competitors. []
 * Make a 4 player mode, with insertable names []
 * Make com names random names []
 * Make com smart []
 * Save times died and won []
 */

/*~~~~~Notes~~~~~~~~~~~~[-][X]
 * Max Rand is 2147483647.0f │
 * or thing: ||
 */