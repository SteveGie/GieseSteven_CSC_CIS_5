/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steve
 *
 * Created on February 3, 2022, 1:21 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

string ranname(string);
/*
 * 
 */
int main(int argc, char** argv) {
    srand(static_cast<unsigned int>(time(0)));
    string def="Fuck";
    cout<<"I choose a random name, the name I choose is... less do the debug first\n"<<ranname(def);
    return 0;
}
string ranname(string def){
    fstream pulfi;
    string temp;
    int count=0, rnam;
    pulfi.open("names.txt");
    cout<<"counting the files\n";
    while(pulfi>>temp) count++;
    cout<<"I counted "<<count<<endl;
    string pulnam[count];
    pulfi.close();
    pulfi.open("names.txt");
    for(int i=0; i<count; i++){
        pulfi>>pulnam[i];
        cout<<pulnam[i]<<endl;
    }
    rnam=(rand()%((count-1)-0+1))+0;
    cout<<"Looks like i choose......";
    return pulnam[rnam];
}
