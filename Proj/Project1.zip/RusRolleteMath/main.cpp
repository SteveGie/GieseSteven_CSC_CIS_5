/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Steven Giese
 * Russian Roulette
 * Created on January 25, 2022, 12:30 AM
 * Ver: 0.T.R, test of randomizer shit
 * Testing saving and loading data.
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;
//Seed
unsigned seed=time(0);
float rper=2147483647.0f;

/*+----------------+
 *│ Prototype Zone │
 *+----------------+*/
void makefil();
const float CHAMB=6; //6 chamber slots


int main(int argc, char** argv) {
    srand(seed);
    float shots=1, chance; 
    char ask;
    while(ask != 'q'){
        cout<<"This is a test of randomness\n"<<"Gun is aimed at your head, pull trigger? y?\n";
        cin>>ask;
        if (ask=='q') break;
        while(ask != 'y'){
            cout<<"Cmon bitch just freakin pull it";
            cin>>ask;
    }
    chance=shots/CHAMB;
    if (rand()/rper<chance){
        cout<<"Bam you dead\n";
        shots=1;
    }
    else{
        ++shots;
        cout<<"Whew, lucky break\n";
    }
}
    return 0;
}

void makefil(){ //Worry about this later
    ofstream score;
    score.open("Score.txt");
    cout<<"I made a new file";
} //Creates a file if it doesn't exist already

/* <><><To Do list><><>
 * Make a 1 player mode with 3 com competitors. []
 * Make a 4 player mode, with insertable names []
 * Make com smart []
 * Save times died and won []
 */

/*~~~~~Notes~~~~~~~~~~~~[-][X]
 * Max Rand is 2147483647.0f │
 * 
 */